<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Scripts -->
        <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

        <!-- Fonts -->
        <link rel="dns-prefetch" href="//fonts.gstatic.com">
        <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

        <!-- Styles -->
        <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

        
    </head>
    <body class="antialiased">

    

        

        <div class="container-fluid p-0 m-0 cabecera">
            
            <?php if(Route::has('login')): ?>
                <div class="hidden fixed top-0 right-0 px-6 py-4 sm:block ml-2">
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(url('/admin')); ?>" class="text-sm text-gray-700 underline">Home</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>" class="text-sm text-gray-700 underline bg-danger p-1 rounded text-light">Login</a>

                        <?php if(Route::has('register')): ?>
                            <a href="<?php echo e(route('register')); ?>" class="ml-4 text-sm text-gray-700 underline">Register</a>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
                
            <?php endif; ?>
            <div class="d-flex justify-content-center align-items-center">
                <img src="img/logo.png" alt="">
            </div>
            
        </div>

        
            <div id="carrito-icono" class="carrito container shadow rounded p-2 bg-white">
                <img src="img/carrito.svg" alt="">
                <span class="valor-carrito" id="valor-carrito"></span>
            </div>
        


        
        <div class="container-fluid"  id="cont-producto">
            <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <h2 class=" text-center text-danger mt-5"><?php echo e($categoria->nombre); ?></h2>
                <br>
                <div class="row justify-content-center p-2" >

                    <?php $__currentLoopData = collect($categoria->productos); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>      
                        
                        <div   class="col-5 col-lg-2  bg-white menu-item mx-2 my-3   shadow p-3 rounded d-flex flex-column" id="">
                            <img src="/storage/<?php echo e($producto->imagen /* asset('img/pizza.jpg') */); ?>" alt="" class="w-75 rounded-circle d-block mx-auto ">
                            <h3 class="nombre_producto mt-2 text-center" data_titulo="<?php echo e($producto->titulo); ?>" ><?php echo e($producto->nombre); ?></h3>
                            <p class="descripcion_producto m-0 text-center"><?php echo e(Str::limit ( strip_tags ( $producto->descripcion ), 100 )); ?></p>
                            <p class="text-center mt-2"><strong>$ <span class="text-center mx-auto"><?php echo e($producto->precio); ?></span></strong></p>
                            <button class="btn btn-danger boton mx-auto d-block mt-auto shadow rounded-pill" data-id="<?php echo e($producto->id); ?>">Agregar</button>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        
        
        <section class="mt-5 pt-5">
            <h2 class="text-center">Pedido</h2>
            <div class="container">
                
    
                <table class="table w-100">
                    <thead>
                        <tr>  
                              
                            <th scope="col">Producto</th>
                            
                            <th scope="col">Acción</th>
                            <th scope="col">Total</th>
                        </tr>
                    </thead>
    
                    <tbody id="items">
    
                    </tbody>
                    <tfoot>
                        <tr id="footer">
                            <th scope="row" colspan="5">Carrito vacío - comience a comprar!</th>
                        </tr>
                    </tfoot>
                </table>
    
                
    
               
              <template id="template-footer">
                  <th scope="row" colspan="1">Total productos</th>
                  
                  <td>
                      <button class="btn btn-danger btn-sm" id="vaciar-carrito">
                          vaciar todo
                      </button>
                  </td>
                  <td class="font-weight-bold">$ <span>5000</span></td>
              </template>
              
              <template id="template-carrito">
                <tr>
                  
                    
                    <td></td>
                    <td>
                        <button class="btn btn-info btn-sm">
                            +
                        </button>
                        <button class="btn btn-danger btn-sm">
                            -
                        </button>
                    </td>
                    <td>$ <span>500</span></td>
                </tr>
              </template>
        </section>

        

        <div class="container d-flex flex-column justify-content-center align-items-center">
            <h2 id="ingresaNombre" class="text-center">Ingresa tu nombre</h2>
            <input type="text" class="nombre mt-2 form-control w-50" id="valor">
          </div>
        
        
        <div class="container d-flex flex-column justify-content-center align-items-center mt-3">
            <h2 id="ingresaNombre" class="text-center">Método de envio</h2>
            <select class="my-1 opcional shadow selector w-50"  id="metodoDeEnvio" required>
                <option value="">Elija una opción</option>
                <option value="Envio a domicilio">Envio a domicilio (+ $100)</option>
                <option value="Retiro por sucursal">Retiro por sucursal</option>
            </select>
    
            <input type="text" class="direccion mb-4 w-50 mt-3 form-control" placeholder="Escribe tu dirección" id="direccion">
            
        </div>
    
        
    
        <div class="container d-flex flex-column justify-content-center align-items-center mt-3">
            <h2 class="text-center">Método de pago</h2>
            <select class="my-1 opcional shadow selector w-50" id="metodoDePago" required>
                <option value="">Elija una opción</option>
                <option value="Efectivo">Efectivo</option>
                <option value="Mercado pago">Mercado pago</option>
            </select>
    
            <input type="text" class="direccion mb-4 w-50 mt-3 form-control" placeholder="Abono con $..." id="abono">
            
        </div>
    
    
    
        
        <div class="container cont-enviar d-flex justify-content-center align-items-center">
            
            <button class="boton__whatsapp text-center shadow rounded-pill">Enviar</button> 
        </div>
        
        <footer class="footer d-flex justify-content-center align-items-center mt-5">
            <div class="row justify-content-center align-items-center">
              <p class="text-center">| Copyright @ 2020 - </p>
              
              <p class="text-center">TuProyectoWeb |</p>
            </div>
        </footer>


    </body>
</html>
<?php /**PATH C:\xampp\htdocs\Delibery\resources\views/welcome.blade.php ENDPATH**/ ?>