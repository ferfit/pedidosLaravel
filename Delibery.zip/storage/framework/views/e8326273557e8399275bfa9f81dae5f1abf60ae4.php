

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <div class="container mt-2">
        <h1 class="tart">Listado de categorias</h1>
    </div>

    <div class="container mt-3 ">
        <a href="<?php echo e(route('admin.categorias.create' )); ?>" class="btn btn-success shadow">Crear categoria</a>
    </div>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
    <div class="container mx-auto">
        <table class="table table-bordered table bg-white shadow">
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($categoria->nombre); ?></td>
                    <td>
                        <div class="row">
                            <a href="<?php echo e(route('admin.categorias.edit', $categoria )); ?>" class="btn btn-primary mr-2">Editar</a>
                        
                            <form action="<?php echo e(route('admin.categorias.destroy', $categoria)); ?>" method="POST" >
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <input type="submit" class="btn btn-danger d-inline mr-1  "
                                    value="Eliminar">
                            </form>
                        </div>
                        
                    </td>
                </tr>  
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Delibery\resources\views/admin/categorias/index.blade.php ENDPATH**/ ?>