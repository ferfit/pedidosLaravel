<?php return array (
  'producto-index' => 'App\\Http\\Livewire\\ProductoIndex',
);